#pragma once
#include "controlador.cpp"

void LISTAR_BENEFICIOS();
void AGREGAR_BENEFICIOS();
void ELIMINAR_BENEFICIOS(int countBenefit);
void MODIFICAR_BENEFICIOS();

void EXIT(bool &);
void DEFAULT(bool &);