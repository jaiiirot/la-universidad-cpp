#pragma once
#include "controlador.cpp"

void INICIARSESION();
void REGISTRARSE();
void EXIT(bool &);
void DEFAULT(bool &);