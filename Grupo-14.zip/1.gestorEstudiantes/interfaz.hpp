// Archivos de cabecera
#pragma once
#include "interfaz.cpp"

// Mostrar Opciones
int NavegacionMain();

// Crear/registrarse
Estudiante CrearEstudiante();

// Validar/iniciar sesion
Estudiante IngresarDatos();
